from project.animal import Animal


class Reptil(Animal):
    def __init__(self, name):
        super().__init__(name)