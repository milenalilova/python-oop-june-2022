from project.reptile import Reptil

class Snake(Reptil):
    def __init__(self, name):
        super().__init__(name)