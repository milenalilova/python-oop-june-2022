from project.reptile import Reptil

class Lizard(Reptil):
    def __init__(self, name):
        super().__init__(name)